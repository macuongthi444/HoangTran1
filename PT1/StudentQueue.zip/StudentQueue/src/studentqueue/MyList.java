/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentqueue;

/**
 *
 * @author hoang
 */
public class MyList {

    private Node head;
    private Node tail;
    private int size;

    void clear() {
        head = tail = null;
    }

    public int getSize() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void addLast(Student s) {
        Node newNode = new Node(s);
        if (isEmpty()) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        size++;
        
    }

    public void removeFirst() {
        Student s = null;
         Node newnode= new Node(s);
        if (isEmpty()) {
            return ;
        }
        newnode.next=head;
        head = newnode;
        
        if (head == null) {
            tail = null;
        }
    }
    private Node getNode(int index) {
        Node current = head;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        return current;
    }
    public Student getStudent(int k) {
        if (k < 0 || k >= size) {
            throw new IndexOutOfBoundsException();
        }
        Node current = getNode(k);
        return current.data;
    }
    public int size(){
        return size;
    }
    public Node searchByID(String key) {
        Node p = head;
        while (p != null) {
            if (p.data.getStudentID().equals(key)) {
                return p;
            }
            p = p.next;
        }
        return null;
    }
        
    }
    

