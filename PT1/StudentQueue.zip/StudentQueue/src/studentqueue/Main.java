/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentqueue;

/**
 *
 * @author hoang
 */
public class Main {
    public static void main(String[] args) throws Exception {
        Queue q = new Queue();
        q.enQueue(new Student("s010", "hoang", 9 , 6 , 9 ));
        q.enQueue(new Student("s015", "van", 7 , 8 , 9 ));
        
       q.deQueue();
    }
}
