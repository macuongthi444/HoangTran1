/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentqueue;

/**
 *
 * @author hoang
 */
public class Queue {

    
   MyList list = new MyList();
    int front;
    int rear;
    int size;

    public Queue() {
        front = 1;
        rear = this.size;
    }

    public void clear() {
        list.clear();

    }
     public boolean isEmpty() {
         
        return list.isEmpty();
        
    }
    public void enQueue(Student s) {
        if (isEmpty()) {
     
            list.addLast(s);           
            System.out.println(s.toString());
            rear++;
            
        }
    }
   
    public int size(){
        return size;
    }
    public void deQueue() throws Exception {
        if (isEmpty()) {
            System.out.println("hang doi rong khong the lay phan tu");
            throw new Exception();
        }
        list.removeFirst();
                
        }
    
}
